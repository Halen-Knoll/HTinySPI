# HTinySPI
SPI library for the ATTiny48 chip.
